\
    #include <jni.h>
    #include <android/log.h>
    #include <link.h>
    #include <cstring>
#include <mutex>
#include <unordered_map>

    #define LOG_TAG "GkModMenu"
    #define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
static std::mutex gFeatureMutex;
static std::unordered_map<int, bool> gFeatureStates;

    namespace {
    const char* kIconBase64 =
        "iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAf1ElEQVR42u2de5Ad1X3nP+d038fMvfMSkpCFpAULIWKxEDAylrVYDyQUE+zgsiWT8rKJ7RSE2ItxUbgSs1lJ64JUmZDFjjGOt2KvY2+FSGyF2AQshBjJlCxAYLMYYiQhZCQsFD2Y53129zn7xzk903N1507fmTuakXy7ampUmr59+5zv7/zeD8FZdmkQW0HOArEKAvNfw1c3dALzsrAgB8sEtCrzO6HBEXC5AEdXPFeYBwUaXhHmtydhj4Z8BvYMwmHg7VXQW/nRbnBOgF4PSlS8z3S/xNkE+nrzwkH0by/AfA/er+BaDVcq+B2gKwUpxy7Qj9xfGuO7UpF/u5a6AvO5EtAj4VcCfiHh2QS89AE4UvGuzlbgbCGGaU0AG0FuAhEF/Qloz8JSDR+RsELBkgy0SAu0Z38r0AJUSECRhcoxvjb8DCGAGqQE4QIJSxgKyEFBwmsKdgl4chD23gD9UWLYBHqzfWaTAGJeW8BZHwHwCUh1wboAbtKwNgnzXAt22YARigKhQYrJWZu2RKHC75LgJC1R+OZd3haw3YHHemDbDZbhaJBbQWyo4F5NAqgO/BDr3A2XAjdr+FQSLpVA0QCvLBAh4GKKRFNIpFqDTIBMW+5QhtcF/BPwyHJ4PSrKphMhiOkC/GsRVrkH1ir4QgDrspAqGhkcgi5jsPGpuhSgNMiUJYZBKDmwTcI3l8H2ULQtmSYcQUwDGR+yVZ6FtRLudmCtA+Qte7cnfLqCPioxaNASnFarSAawXcH911pC0Hb9U6kjTBUBhKw7iJz4ux1DAOQsWxUGdMHZfWltxVUGpLKEIOH+ZcOE4ER0i3ObALaAE7K+brgsAfck4WYs8Fb+O5ybV6AtIWD0hEc8uHcVvFq5N+ciAYgtVgHaAsm58BcCvpKE5OAZBl5P/WYEGkQWZBnKGu47Cn+1AcqWCM4YNxBnaMNlKOd3wToXHkjDksFhGe80GmBdAXa4UKeGMmHZc9XPicmwKyGQ4GSNdfOaD3etgG2Ve3ZWE0A3uKvA3wjudXB/Eu7URqv3rewTjQLc2uk4QNL+Dr15ngV+0CqX1a5WIGsJIRHxIgbW3xBEvqNRBGFNySAFrjDf8+AOuHsz+OHenbUEEC7gKViUge+1wPJ+ox0jJqjVa4aPRwLjwg0dMn3AO8BxYD/wLnDQEsQJ4NSw7z8aB+A8YJYFeiEwA7gEmA28B+iwBOVZl7IXcS2KiROCEkA7yALszsFnrocDk00EYrJ89xj3q9oJGxLwcAJmDIIvzR5OyNDWFuwWu4AeC/TL9vc+C36j+Ke0RLDYEsTv2t9d9l0KlhgaYasq8LPgevCuB7evhC3aPFZPRmxBTIZtv3lY3m9Kw0bPbNCEZH1gN7fVnuSTFvCfAj8Hjo0CnKii+MVRAkUVThO95gBXAR+2BDHTvqP1XUxIqdEQJMBJGN1g8wrYVLm305IAQsXlMWibDQ9m4LM9ECgbTBkv8K6VzSXgFeAJ4zvgRMVCZAWXaPRGjfb8WcAy4AbgciuOBq04csbPCbQE1QVODr57HO68CQYarRyKRoP/OHR1wLYsLO0FTxhuPS7gHaANE157BvgJsLfKCZ8KD0pIEJUcYinwe8BqI88ZiKxlnPvqdUJiEPb2wboboaeRRCAaDX4nbEvD0oFxgh+uKmvZ6VPAPwKHKjZ+StxmYxBD9J0uAv4QuN6KrcGYsejRiKANEkXY29tgIhCTAX7/OJU9PyLjnwUeigDv1JDH0+kKuVIQIYTPA9dGdAR3nMphO7iNJgIxHcBXduM6MHHTrwPPRYCfTqe9Xq4QEsIHgS9i4tt9kTVPNRHIiWj7jQDfj5hzDwN/YsGXkQ0828AnkkoWruM5u7aH7VpbqN+4l+D2g5+GpZ2w7XHoEqA2TgBHMQE7nx9DSxfsbBkn+AEmg/MN4KvYiEhEnp5LV3RNlwF/CVyMyTB1xskJCrC3B1Z+1LgiGI+fYFyUs9O4cHU7fCtrFb56wA/dtl3WpPsTC74T0erPtUtF3NSv2jU/EXEm6To5wQB4WVjaDt8SoHeO09Bwxuve3QGbzoMv9tSp7auI6/Z+4JsYP7s8R4GvRvzS+jS6rRfzwxGOGJclC3CK4M2Aq9aDWA3PdIP7/Tq3UdT58o6A4Gn4ZBtsLYKn6wA/sLKv37LAvRFbWvPbdYkIt1tqRWA7hpc79T3HS0NiANavgUdDjBpOAKE/+mm4KAMvBtDpmweIesAfAO7A+OtdJjnUdRZc4R4sBr5hHV/1EIEG7Zr7e3Nw9RpjOYu4loGopzADYDbsboVrcnX49pvgTzoRBBlw8vD8cVgO8QtT4iqBcgMEM+GvO+CaQfAnAr7TBP80U9ixe3OH3asW4vNxAc4g+B1wzUz46w3DFujErYAtVqZ0w5oM3FmPuadGAT9oYj5q7KOSCFSdPoIM3NkNa4RJvXMmJALCuP53wFkMr6bgkqJhLTKOtusCOesBa4If3ywLrDj4OpCxHELETCpJgyzB/n1w2a3Wj1ZLFIwFpBSgLoZ72gz4QT2ZPEngK03wx80JvmL3sA6NXhYhaINLLoZ7RAyPsxjLz78TFiVMwqKjjHYp4iyiC7gPeLSp8E1IMfykJYSemEqhLUbRLgQeLFkJB2rFC0aljq3DQN+bhIStthVxFJpO4HELflPhm5hi+Kjdy86Y+yhAKNBJ45+5twLLeBwgLFDohpVZ6M7FzGkIlb4jwOcYjoHrJp4TCtRkgb8H5lvzMKYMDjLGOli1CnaOVnRS9Vnrh+viN+o68JOY5MiNVosVTfCZqNtY2L3cGEltryflXJuPDmE6JgFYs091w8oMrMzFrNjxMfH87wO/isTxmxcTDiI5dk+/b/c4pkh1cqAzsLIbVgpQ1cxCWev0i5ghRoXJ5NkHPPJbFNg5k0Qg7d7us3ut4okQbbnwqFxAVjv9u2B1qzn9sTOcXUx0L9eU+5NWy5ize1xH0oWTA9UKK3fB6mpcQI5CcXc5dZz+LLALeKl5+iedC7xk9zpbBxew4viumjrARuvv3wELE7AqNxy6HlPxK2CCGKKJ0xmxDL5RnzUgc6ATsGoHLNwAQTSFbOgfK+2/JdzSOhyLEGM5fNqAJ63p1zz9Z4YLHLF73hbPuyqAoNV0UrslivWI6mcN7IF0GX6ZhPeWY3IADfwX4O1zOJ2LaZZbqIF5wD/E57oqCaIMbybhPy6Dov2cllb5kwJ0EVZnYGExBvjh6d/RPP1TxgV2xOcCsmhMwoVFowzqLcMcH9YPs4P1wtakxeErZYybsunwmRoH0eMWAxGPcyhrFq6PYi5tF83gn6FTwrqiEQfOWFSYwVTnvtxk/VOWYRzufybG/muTRCokrPtn6LT9kIUMU73a4Mo0zLFNGEWcWP+/nk0Nh8/ROMG/RrqgjBUk8ky+wJw2uBJgK0jZYwnAhY+4kZ59tcBPYEqzd1cUdDavM8sFsBicsJjEIALlWqwBekDKo4YVSAVrvHhZQrQAv7AxatmU/1NaX9BjsWiJh4PwDPGs0SCPQiA3g9oNcxxYXBpO/x5TAdnVZP/TRgzsiqmIa5MuhgOLd8OczaDChoVLM9Cqh9uy1pT9PQw3amiy/6kXA3stJmPpAsIo+EEGWsumHmXIFlwhY8RwNJDGRKSa7H96iYF9FpsYeGhbsbwiNAOlhqv8mPI/YWWOarL/aSMGlMUkEVMP8M19V2mQ8l+MGXmJF0P+h50vDjRDvtMuVHwgZnGpBmmV/Uv+BTKyDRY4Mer8wrSgPuDfmgQw7Qjg3yw2Tgw9wCacdrbBAumY8G+LiiH/k8Bv7Bc13b/Tyy3cZ7FJxsBFmfBwiwMLJXC1E8MBFGb9HGO4K2bzmj56gGexcePdr6yv/2opIBOz7AgH03N3NG1RAo4QOKPkkYkx/h4+wxVi6McZ5bucKj/19uwd+qwQVZWf6HpkjXVU/lS7T9Z4drX7RbV3HeU9w3sPxhABFf0JMq6GD8WxAEIiODXmvDVdOYxxZOMkrcdsmKCq3FMZbq4VAnWEQGk95kYEI+aBVdeuq/2t1jpq3Rfdj2rPrvXcYJR3iV6n4ovl0BL4kBs3xzBkM9UsgHBhS1IpZrsuAhgMAl4oFkdQ1hzX5dJUCiw4zxcKFLQe+rwGrkinWZpOM9txyGnNq6USu3I5/AgRSOCalhbSUqK1NoMdtebdIOAtz8OzG1VLT4k+A+Btz+NAuTyiR/D7UinOd13QmkGleLFYNMkYrsuiVApt1xH9jpLWvFgsEmg9dJ8Ajvs+r5ZKQ2t4byLBf0gmCbTmhUKBYuR+gFeLRU4EhkSTQnBNOo0rJSd9n1+WSiPWFrUE6hTPrqvr6EjijFKsGLZzu2/WLD7W2QlBgNaaS998kwPlMq4QeFrz7TlzzN+VAq25+I03OOgZo6TTcfj2nDmsb29HOo7pLqw1BAH/r1jk9nfeYU+hgAASQvDYvHnMTibtwDZzrx8EHCyXeaS/n786dYpShLgqiXXEM4ADhQKXHTo0RDxZKdkxfz5zLCD78nmWHDpEAKxvb+dvLrgAfN92QQ4nFQpKpRLnv/EGfVqb++bOBaXo830Wv/kmJ33Db/+sq4u7zj8f3/NYdPAgv/Y8NrS388DcuaA16w8f5tGBAQBmOA47FiwgkUzyZE8PN7z99ogehESKcZ06W/5I4PJSjErhcNjCiRr35LVGKUVBKYTjcGtnJxrwteaSZJJ12SzK91FKUVRqCBhHCLbOncunOjuRwLP9/Ww6epQfnjqFpxRXpNP8ZP58FluwHCEYUAqlFO96Hk/39fH84CC+1ixuaWHj+efzo3nzSAtRc7DDoH2G5/ssSqe5PpMZOtGfaGtjTipF2fdRWpOLsN+y1qggwFOKX+bzdPf380x/P939/Tw2ODhUuFHWGqU1ed+nI5Hgz2fMGAKtZPdqILIPZft/SqkhQgxPeLjefA0xcMJiFCNZVFrML5cyBtGECuCA7cM/mg9AAtLK3yAIuKWjg/McBw3c3tlJynHIKzXUPNGxJ+fjbW2saW8nUIofDQzw4cOH2XzyJLccPcod//7vKK1pTyT47zNnDpk9AFJKXi+XWXvkCB986y2WHDrEUwMDKKW4vr2dO2fMqFnYEHbzLNpNvaOra2gdX+jqAq0pa33aoMLwcwkp+a/HjrH68GGuO3yY1W+9xc1Hj1KKgCQtt0Epbu3q4pJkEmHl7mjPrabMyhoDE8NvO24xiqsISnBknf3paioMWpv8ov3lMj8ZHGR2Os2N2SwO8JnOTno8j8cGB0HKEV6rj2UyKLvRXztl1My01Ya/09PDr0sltNasbG2lRYgh1h7dGBd4s1zmj48eZTAIUFrz6fb2ob4EYjSlVUp25vO8Xiyypq2N+a7LFek0V2ez7M3nea5QACGq2shaa65tbWVVayurMxlWZTIsSaVO2/ycUuzJ52mNErEQk1JSLscRS2jIxK3KjX2otxe05o86OvhcZycd6TRb+/t5oVAAq7yFmzo/kUACuSDgsO+bfEN7ijRw0PMQQtApJbNcFz9CANFhTw7wju/zulW23uO6dFgOVItgD3sef9fbi3Bd/rSri1s7O0FKvtXTw/EgACFOf4YQBFrz1TlzeOa972XHhRfyzMKFPDB79mmafFJK7jt1iuOlEjd3djLfdelXauRI60mchjYpvYJrXR1SsiOX4+XBQVZkMtw/ezYEAQ/39tYwM0RDF1bPlZGSH/T1USyV+NKMGXy2s5PeYpGtAwO0S1njlQWv5PM83dfHU/39PN3Xx7P5/GncplUIXimV+JtTp3Bcl/82cyZ+xFJhihtRNLy5sCMEZa15qLeX/9XaSrvj8Fo+z8vFIjdms0NmYLi1RzwPpTUZx2GB63LE80hZywHg4kQCrTW9SnHC93ErTmQoBnzgAmtqKssN+oJgzHfOSMmpIODHAwOs7+wE4Lu9veSUomU0AtAaRwj+4vhxnsjlRvwpEXn3kIDbpeSh3l6+PHMm/7mjg5eLRbD6UHj5dl+EEEghcCJKrLQHJGhw42cp6kxA8GNNRdS4QrClv58Tngeuyzd7eoZ65Vae7B/lckZ5BL583nlgFbMAuK2riwtTKYQQ7MrnKWhNKkIAKvJeC5NJvjd3LlkpkULwf/r7h0SDjuFP/9uQQ2nNw/Z9ldbj6vNzWhqdEAwqxddOnqTVdflQS8tpBPBrz0NY0XhNOk2gNb7WXJ5KkZUSDRy2ZnM1HcKvM0FHAG6cwY0iUggyG3hrFCeLishjF+hXiusOH2am6/JCoWDm99kFqojX67GBAXb093Ndezsfa2vjpwsW8HQ+z6Jkkk+1tyOFoN/z2Hzy5EhvmlJcmkyyff582qTkinSatGuY2lP9/Tz47rtV7eXK9w1P3s/yeVYcOoQH/LJUMiZs5L7KkXWBUtw3axZfmjHDiDCt8YHbjh0bAipKoAL4Vm8vt3d1Mc/6MKL7sLtQ4Ei5zPxUij+bMYM2KelRils6OpDW17HF+gZUFQ/j7EihiIh3oAMXeCUFV5bG6Cil7MNnWQKodrUKgZRyiFqF3UhKpSGTL2nvaZNy6CV9rVl/9CjfVopPtrdzbXs713Z2nuYI2mc9dYHWtEmJlJIZiQRrrHcxCAL2FQo1HUHRK2uf0RI5TT8tFEY0aQrXlInckxQC6ThIrbkikxmpv2hN23FjLKfsZ6W1cEJ7/n+cPMnfz58PSpGNvE+/Unz6nXf4h7lzuTCV4vbZs23VRkAuCLjn+HGeLxRGrcKaZauGB8ZW7lTKVAu9InbC3hRcHYcAWoFb7eSu6EtUuoILSvFCoTD0QCHEkNZ/YSLBRckkyrpACxUgXZFO84F0mlmOQz7iCvbGcAWXteZUna7gD7S00CIlx32f16x7tXIy2BWpFDNcl4Eg4KUYrmANvFQokI+6dq17eECpoe/4T62tQ+t5rlCgZIlEAZ1SsjqT4eJEAkcIfuP7PJvPc8jzqq4p/NzlwHfsWJo4BFCCF8VO2JOCD45FAOFwh/uA/zsJff/EGBVG9dQexg0GMc0HS8T9W4jFJzAt5WIMoQgJ4Dkp4GduTGtLYMar1nr5yhBnrZBwtVGwo4WDVR3h4CAm+LVCrJVrmmg4WNR4/6qDJSJ74NrvH+sAnBffEtC2COhnroZc3PhxOFN3NGpRMUKWY4VSVUzNuxHcJ06Itd6wbV3h3XHu0Wh+koV1KIBWdOUkpvf/mAmhoZkxJ372afPizKWFJSw2fszZD5YAX5QBHPSgMNZo17Ac/ALbqkw308KYLulg2mJyQcxycWlKxAoBHJQDcDiAXltVoscSAR3A+5plYdOuPOx9FpuxREA4YSSA3gE4LP/AdB/bn4hZGewAi5oEMO0IYFHMMLAAZYc87f8DyElh+gH8PI4lEKaFXdksC5t25WFXxk8HCy2An4uwOFTBLhXjUAugiBlm0NUsD5s2ZWFdFpNiPDyEdU/vGgoHJ2FvDvICnLH0AN9+4dLJjCc3r7pi+UstJn4M+S9M99B80hZ4y40gl8OxAPalYugBoda5olkeNm3KwlbEtMqE8QASwL7lcGwjSDnX9geW8HQiph5QsDKnKQamB/u/0mISR/4nDOd4WoCaC47ssifehyf9mBXCHibytLwpBqac/S+3WHgxK4N9izWGeJRcbwlgAH5RhGMJ0y9gTC7gA7/fFANTzv5/P+ZUMW1OvyzCsQHTToD1oKRJY8D5OPQq2JY2ikIwFvXlgN+1P7rJBaakXWy4/7kY+y8gSINWsO3j0GtnDJtWsVuHqWSrNmZCrB7BSeDGplt4yty/N8YsB7emvtSmR9DWKObNZtHNZtHmHzvB+RAUNPwwHRPLADPy/NNNLnDGT/+n7d7HDIurtDnkP/wQFHZGvMZDJ3ynBVzBD/LDw6v1WAkVA5i2k/OJMaayeTUkW2i+3fOBeMWgGjNZvKDgB1GsRxDAZjtP5joTHu7OxOQC4azAO5rWwBnT/u+ob7C0ypjwb/d1cHALOJurEUAFpT0QDA+PJk7V8Arg/U0uMOmn//12r2NWAaNB2FnyD8QqJgnnzD4D3VlYmY8xNVRhmhQexkwMLUQaPjSvxiXMtmAmiC7ABH5iEEDQaqaH7lwNq6rNEJajzQwWsFnXwQXymIjUzU0uMGmn/2a7x/k6Tr9VzjePNkNY1JocbrnAinwd8wMlcBtm0mVzjEzjwP8d4O/q28+gFeQg7Brt9I+qA0S5QJyJ4VFRkDAKJW1N07BhJl+b3dNE/bV/otbpH5UANkCwBZxVsDMHWzMmTyCIQ605THry3U0XccOcPnfbPc3FZ/1BxsT9t9aaHF4zAyhkGTthUQJe88GxLQ1EHAdRF6aK6FGG6+yaF3XV7fvAJzHVPj0xZbA23j3tQuDBkpVwYDT2XzOSK0BpcFbCgSLcl61DpIc9he8GrrILcZqYUk83Nt/u3d2RHsBxJXHWRP3us+A7tZJ8xuIoSoN8A+4dgP1pIwpii6Gy5QKLiWFLNq8RdX6L7d6V63MSqTQ4A7D/DbhXxzi0YyV/6K0gbgNPw+dtJw5VT2PJdsys2yYR1Af+N+ze1dP4UdosXw2fvw28rbZrwUQ7vmDZSPAM/M8uuLMHfBmzvUxgHRgDGBfmvkmoLD4XwW9jOCAT0wLzu8DtgQdXw5dCzBrR8gcNIpwvOBt2t8I1uRidRWoRQVMxPF3hGy/4odafh+eP20y99XZSaEMIgOFcQf00XJQxBaVjDploEsEZAV+75v7eHFy9Bg7ZnmuqoW3i7APlWngzD7cmzRhSvx4WV7AL/Doml90fR4v3c8nJE3Y2W2r3pF7wLYB+EkQebl0Lb1LD5Jtwn0ABQTe4a+DRQdjcCQlt9JTYRFDEDCn6W+NwGmrF8tvkMJKRhhgb7F5k7N7U2ezZ64TEIGxeA492gyvqVK/Gdfi6wV0F/k743x3wR73gCeOprCujtQMz+/ZrkeQGdQ5HEUWks3ob8GVMVm/fOMAIwe+D76+EPw4xmYy+j1WVQoAfQ0sX7GyBpf11WAaVfYfeAL4KvDqOfkBnY++fy4C/BC4mVj+fqhp/O7gF2NsDKz9qJAdiHGdnXGb5ZrumP4XyJ+BRF1ZnYH4RfFEHNw/DyLOA38NkuL5unR/yHBlMJSPJshngM8CfAzOA/nG0ag3BL8LePlj3UdsVbtU4t0pMMD1JClCPQ1enqSkYFycI8wc6LAF8HXguQqFno1iIsnuADwJfBC61LH88ORNR8Hth3Y3Qo+tU+hpKAI0kAsLGjBb0Z4GHMDYNkQxVdZac+BD4i4DPA9fa/8uPp0HzJIHfsCYf1YhgoE7FsHIgctZu1lPAP0YIQUTkqZ5mpz36ThcBfwhcb4l6cAJ1lBq8Nkg0GvyGdnmJEkEHbMvC0t5xEgGRuEGblZXPAD9heGp5pXzVUwR6JVdaavWZ1Rhf/sAEYyARU29vX4PBb3ibn/DFHoO22fBgBj7bA4Gyo5XGSwiu5QglTJvaJ4A9jJxfVK3N62QAXu35s4BlwA2Ydq0pe+InEgZXJq6vukxix3ePw503wUAjwWec4qimt3AjyJsM4X9uFxxpgY0e4NURO6g0U7Q1l8JeOFcDJ4GXgZ8CP8dMzQxGkcdU6ec71mkQFR1MdcXz52Di9R/GFGjOjMj4wihdQOs4SEESnAQ4vbB5BWwC2Nhg8Cet0Zf1EwibUbQhAQ8nYMbgOJXDSh0hbIzYYhfQA+y3BLEfE2c43kCFUWJasS8GLrGAX4LJetIWcK+CS0xgfX4WXA/e9eD2lbAljMOISZB0k+qGD71TT8GiDHyvBZb3myQTxAT3Kip7E5btJizb7QPesUSwH3iX4bGqJzATNqM+hvDf51l2HrbEnWGBng28x5qprgW7xLAPvBHxDG2id7SDLMDuHHzmejgwXg/ftCCAKBFsBPc6uD8Jd2qzgb6NWTfCFB36EZEBl44FTFuwwiqm/CjPabW6RpjdHDbCCKxzKoh8h2jQ5tnGTUHK+PEpw4M74O7N4E82+Ges12NUcdkF61x4IA1LBu3UCtHgRKFoVZKuWKhTg02riJyv/JyYhM3SEEhwskDRJN7etQK2Ve7ZmWg1M9kmkwLEFnBWwLbfwFUF2ORCOTucZxg0WmOXFa3kQ7PNH+VH1/hcg8EPtEnedFwoF2DTb+CqFbBti/laIc6Qz+uMh+KjOerdcFkC7kmaqidyw1ks52rqYKBBZOzBK8MjHty7ysbBauXvnzMEEOlIIsPY9R5Yq+BuB9ba4hJltd5zIV9EWw4nMiAtq9su4f5lsD2Sczklzs2pysPQAoKNpm+NXAbbl8P1nvnZ3gIyaxVEW5F0NkaHlTb6jciC0wLSg+0eXL8crl8G27Vt1CmG9cspazY9pdcWcF4DHTYusBzhCwGsy0KqaKwGJYaDaNM1gUiFtRQpkGljdZQc2Cbhm+GJ3whyCYgN0yA5elqx1y3gRLNZd5vo6c0aPpWES6VNm/KGiSEUJWKKunXokHVrkAkLujLy/XUB/wQ8stxEuYeyqzdMo6z4aSlfLSGEm8sTkOqCdQHcpGFtEuaFDpmyNSVDE10PT0MVkyDLichqIcFJRhxQZXhbwHYHHuuBbTcYfxEa5NZpcuLPCgIIr40gN9nRieH/PQHtWViq4SMSVihYkoGWMMPWG572OURAeuRoRxknIq0jKVbaBrNcC7Zrb8qZUTuvKdgl4MlB2HuDCV4OFdRsiog2pvHAieneGElsBbneZiZH//YCzPfg/Qqu1XClMr0UulKQciLevPAqjfFdKUZGysIgUMl8tEfCrwT8QsKzCXjpA3CksopqK/ELM5oEME5imAViVRXtudvkmc7LwoIcLBPQqszvhDW3LrdzEao1Ywg0vCLMb0/CHg35DOwZNC2Q3l5lApMjPtoNzgnQZwvo0ev/AwF4Cgqwg2nRAAAAAElFTkSuQmCC";

    int findIl2Cpp(struct dl_phdr_info* info, size_t, void*) {
        return (info && info->dlpi_name && std::strstr(info->dlpi_name, "libil2cpp.so")) ? 1 : 0;
    }

    jobjectArray makeStrings(JNIEnv* env, const char* const* values, jsize count) {
        jclass stringClass = env->FindClass("java/lang/String");
        if (stringClass == nullptr) return nullptr;
        jobjectArray array = env->NewObjectArray(count, stringClass, nullptr);
        if (array == nullptr) {
            env->DeleteLocalRef(stringClass);
            return nullptr;
        }
        for (jsize i = 0; i < count; ++i) {
            jstring value = env->NewStringUTF(values[i]);
            if (value == nullptr) break;
            env->SetObjectArrayElement(array, i, value);
            env->DeleteLocalRef(value);
        }
        env->DeleteLocalRef(stringClass);
        return array;
    }
    }

    extern "C" JNIEXPORT void JNICALL
    Java_com_android_support_Menu_Init(JNIEnv* env, jobject, jobject, jobject title, jobject subtitle) {
        jclass textView = env->FindClass("android/widget/TextView");
        if (textView == nullptr) return;
        jmethodID setText = env->GetMethodID(textView, "setText", "(Ljava/lang/CharSequence;)V");
        if (setText != nullptr) {
            jstring titleText = env->NewStringUTF("MOD MENU");
            const bool loaded = dl_iterate_phdr(findIl2Cpp, nullptr) == 1;
            jstring subtitleText = env->NewStringUTF(loaded ? "Native bridge loaded | IL2CPP detected" : "Native bridge loaded | IL2CPP");
            if (title && titleText) env->CallVoidMethod(title, setText, titleText);
            if (subtitle && subtitleText) env->CallVoidMethod(subtitle, setText, subtitleText);
            if (titleText) env->DeleteLocalRef(titleText);
            if (subtitleText) env->DeleteLocalRef(subtitleText);
        }
        env->DeleteLocalRef(textView);
        LOGI("Native menu bridge initialized");
    }

    extern "C" JNIEXPORT jstring JNICALL
    Java_com_android_support_Menu_Icon(JNIEnv* env, jobject) {
        return env->NewStringUTF(kIconBase64);
    }

    extern "C" JNIEXPORT jstring JNICALL
    Java_com_android_support_Menu_IconWebViewData(JNIEnv* env, jobject) {
        static const char data[] = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAf1ElEQVR42u2de5Ad1X3nP+d038fMvfMSkpCFpAULIWKxEDAylrVYDyQUE+zgsiWT8rKJ7RSE2ItxUbgSs1lJ64JUmZDFjjGOt2KvY2+FSGyF2AQshBjJlCxAYLMYYiQhZCQsFD2Y53129zn7xzk903N1507fmTuakXy7ampUmr59+5zv7/zeD8FZdmkQW0HOArEKAvNfw1c3dALzsrAgB8sEtCrzO6HBEXC5AEdXPFeYBwUaXhHmtydhj4Z8BvYMwmHg7VXQW/nRbnBOgF4PSlS8z3S/xNkE+nrzwkH0by/AfA/er+BaDVcq+B2gKwUpxy7Qj9xfGuO7UpF/u5a6AvO5EtAj4VcCfiHh2QS89AE4UvGuzlbgbCGGaU0AG0FuAhEF/Qloz8JSDR+RsELBkgy0SAu0Z38r0AJUSECRhcoxvjb8DCGAGqQE4QIJSxgKyEFBwmsKdgl4chD23gD9UWLYBHqzfWaTAGJeW8BZHwHwCUh1wboAbtKwNgnzXAt22YARigKhQYrJWZu2RKHC75LgJC1R+OZd3haw3YHHemDbDZbhaJBbQWyo4F5NAqgO/BDr3A2XAjdr+FQSLpVA0QCvLBAh4GKKRFNIpFqDTIBMW+5QhtcF/BPwyHJ4PSrKphMhiOkC/GsRVrkH1ir4QgDrspAqGhkcgi5jsPGpuhSgNMiUJYZBKDmwTcI3l8H2ULQtmSYcQUwDGR+yVZ6FtRLudmCtA+Qte7cnfLqCPioxaNASnFarSAawXcH911pC0Hb9U6kjTBUBhKw7iJz4ux1DAOQsWxUGdMHZfWltxVUGpLKEIOH+ZcOE4ER0i3ObALaAE7K+brgsAfck4WYs8Fb+O5ybV6AtIWD0hEc8uHcVvFq5N+ciAYgtVgHaAsm58BcCvpKE5OAZBl5P/WYEGkQWZBnKGu47Cn+1AcqWCM4YNxBnaMNlKOd3wToXHkjDksFhGe80GmBdAXa4UKeGMmHZc9XPicmwKyGQ4GSNdfOaD3etgG2Ve3ZWE0A3uKvA3wjudXB/Eu7URqv3rewTjQLc2uk4QNL+Dr15ngV+0CqX1a5WIGsJIRHxIgbW3xBEvqNRBGFNySAFrjDf8+AOuHsz+OHenbUEEC7gKViUge+1wPJ+ox0jJqjVa4aPRwLjwg0dMn3AO8BxYD/wLnDQEsQJ4NSw7z8aB+A8YJYFeiEwA7gEmA28B+iwBOVZl7IXcS2KiROCEkA7yALszsFnrocDk00EYrJ89xj3q9oJGxLwcAJmDIIvzR5OyNDWFuwWu4AeC/TL9vc+C36j+Ke0RLDYEsTv2t9d9l0KlhgaYasq8LPgevCuB7evhC3aPFZPRmxBTIZtv3lY3m9Kw0bPbNCEZH1gN7fVnuSTFvCfAj8Hjo0CnKii+MVRAkUVThO95gBXAR+2BDHTvqP1XUxIqdEQJMBJGN1g8wrYVLm305IAQsXlMWibDQ9m4LM9ECgbTBkv8K6VzSXgFeAJ4zvgRMVCZAWXaPRGjfb8WcAy4AbgciuOBq04csbPCbQE1QVODr57HO68CQYarRyKRoP/OHR1wLYsLO0FTxhuPS7gHaANE157BvgJsLfKCZ8KD0pIEJUcYinwe8BqI88ZiKxlnPvqdUJiEPb2wboboaeRRCAaDX4nbEvD0oFxgh+uKmvZ6VPAPwKHKjZ+StxmYxBD9J0uAv4QuN6KrcGYsejRiKANEkXY29tgIhCTAX7/OJU9PyLjnwUeigDv1JDH0+kKuVIQIYTPA9dGdAR3nMphO7iNJgIxHcBXduM6MHHTrwPPRYCfTqe9Xq4QEsIHgS9i4tt9kTVPNRHIiWj7jQDfj5hzDwN/YsGXkQ0828AnkkoWruM5u7aH7VpbqN+4l+D2g5+GpZ2w7XHoEqA2TgBHMQE7nx9DSxfsbBkn+AEmg/MN4KvYiEhEnp5LV3RNlwF/CVyMyTB1xskJCrC3B1Z+1LgiGI+fYFyUs9O4cHU7fCtrFb56wA/dtl3WpPsTC74T0erPtUtF3NSv2jU/EXEm6To5wQB4WVjaDt8SoHeO09Bwxuve3QGbzoMv9tSp7auI6/Z+4JsYP7s8R4GvRvzS+jS6rRfzwxGOGJclC3CK4M2Aq9aDWA3PdIP7/Tq3UdT58o6A4Gn4ZBtsLYKn6wA/sLKv37LAvRFbWvPbdYkIt1tqRWA7hpc79T3HS0NiANavgUdDjBpOAKE/+mm4KAMvBtDpmweIesAfAO7A+OtdJjnUdRZc4R4sBr5hHV/1EIEG7Zr7e3Nw9RpjOYu4loGopzADYDbsboVrcnX49pvgTzoRBBlw8vD8cVgO8QtT4iqBcgMEM+GvO+CaQfAnAr7TBP80U9ixe3OH3asW4vNxAc4g+B1wzUz46w3DFujErYAtVqZ0w5oM3FmPuadGAT9oYj5q7KOSCFSdPoIM3NkNa4RJvXMmJALCuP53wFkMr6bgkqJhLTKOtusCOesBa4If3ywLrDj4OpCxHELETCpJgyzB/n1w2a3Wj1ZLFIwFpBSgLoZ72gz4QT2ZPEngK03wx80JvmL3sA6NXhYhaINLLoZ7RAyPsxjLz78TFiVMwqKjjHYp4iyiC7gPeLSp8E1IMfykJYSemEqhLUbRLgQeLFkJB2rFC0aljq3DQN+bhIStthVxFJpO4HELflPhm5hi+Kjdy86Y+yhAKNBJ45+5twLLeBwgLFDohpVZ6M7FzGkIlb4jwOcYjoHrJp4TCtRkgb8H5lvzMKYMDjLGOli1CnaOVnRS9Vnrh+viN+o68JOY5MiNVosVTfCZqNtY2L3cGEltryflXJuPDmE6JgFYs091w8oMrMzFrNjxMfH87wO/isTxmxcTDiI5dk+/b/c4pkh1cqAzsLIbVgpQ1cxCWev0i5ghRoXJ5NkHPPJbFNg5k0Qg7d7us3ut4okQbbnwqFxAVjv9u2B1qzn9sTOcXUx0L9eU+5NWy5ize1xH0oWTA9UKK3fB6mpcQI5CcXc5dZz+LLALeKl5+iedC7xk9zpbBxew4viumjrARuvv3wELE7AqNxy6HlPxK2CCGKKJ0xmxDL5RnzUgc6ATsGoHLNwAQTSFbOgfK+2/JdzSOhyLEGM5fNqAJ63p1zz9Z4YLHLF73hbPuyqAoNV0UrslivWI6mcN7IF0GX6ZhPeWY3IADfwX4O1zOJ2LaZZbqIF5wD/E57oqCaIMbybhPy6Dov2cllb5kwJ0EVZnYGExBvjh6d/RPP1TxgV2xOcCsmhMwoVFowzqLcMcH9YPs4P1wtakxeErZYybsunwmRoH0eMWAxGPcyhrFq6PYi5tF83gn6FTwrqiEQfOWFSYwVTnvtxk/VOWYRzufybG/muTRCokrPtn6LT9kIUMU73a4Mo0zLFNGEWcWP+/nk0Nh8/ROMG/RrqgjBUk8ky+wJw2uBJgK0jZYwnAhY+4kZ59tcBPYEqzd1cUdDavM8sFsBicsJjEIALlWqwBekDKo4YVSAVrvHhZQrQAv7AxatmU/1NaX9BjsWiJh4PwDPGs0SCPQiA3g9oNcxxYXBpO/x5TAdnVZP/TRgzsiqmIa5MuhgOLd8OczaDChoVLM9Cqh9uy1pT9PQw3amiy/6kXA3stJmPpAsIo+EEGWsumHmXIFlwhY8RwNJDGRKSa7H96iYF9FpsYeGhbsbwiNAOlhqv8mPI/YWWOarL/aSMGlMUkEVMP8M19V2mQ8l+MGXmJF0P+h50vDjRDvtMuVHwgZnGpBmmV/Uv+BTKyDRY4Mer8wrSgPuDfmgQw7Qjg3yw2Tgw9wCacdrbBAumY8G+LiiH/k8Bv7Bc13b/Tyy3cZ7FJxsBFmfBwiwMLJXC1E8MBFGb9HGO4K2bzmj56gGexcePdr6yv/2opIBOz7AgH03N3NG1RAo4QOKPkkYkx/h4+wxVi6McZ5bucKj/19uwd+qwQVZWf6HpkjXVU/lS7T9Z4drX7RbV3HeU9w3sPxhABFf0JMq6GD8WxAEIiODXmvDVdOYxxZOMkrcdsmKCq3FMZbq4VAnWEQGk95kYEI+aBVdeuq/2t1jpq3Rfdj2rPrvXcYJR3iV6n4ovl0BL4kBs3xzBkM9UsgHBhS1IpZrsuAhgMAl4oFkdQ1hzX5dJUCiw4zxcKFLQe+rwGrkinWZpOM9txyGnNq6USu3I5/AgRSOCalhbSUqK1NoMdtebdIOAtz8OzG1VLT4k+A+Btz+NAuTyiR/D7UinOd13QmkGleLFYNMkYrsuiVApt1xH9jpLWvFgsEmg9dJ8Ajvs+r5ZKQ2t4byLBf0gmCbTmhUKBYuR+gFeLRU4EhkSTQnBNOo0rJSd9n1+WSiPWFrUE6hTPrqvr6EjijFKsGLZzu2/WLD7W2QlBgNaaS998kwPlMq4QeFrz7TlzzN+VAq25+I03OOgZo6TTcfj2nDmsb29HOo7pLqw1BAH/r1jk9nfeYU+hgAASQvDYvHnMTibtwDZzrx8EHCyXeaS/n786dYpShLgqiXXEM4ADhQKXHTo0RDxZKdkxfz5zLCD78nmWHDpEAKxvb+dvLrgAfN92QQ4nFQpKpRLnv/EGfVqb++bOBaXo830Wv/kmJ33Db/+sq4u7zj8f3/NYdPAgv/Y8NrS388DcuaA16w8f5tGBAQBmOA47FiwgkUzyZE8PN7z99ogehESKcZ06W/5I4PJSjErhcNjCiRr35LVGKUVBKYTjcGtnJxrwteaSZJJ12SzK91FKUVRqCBhHCLbOncunOjuRwLP9/Ww6epQfnjqFpxRXpNP8ZP58FluwHCEYUAqlFO96Hk/39fH84CC+1ixuaWHj+efzo3nzSAtRc7DDoH2G5/ssSqe5PpMZOtGfaGtjTipF2fdRWpOLsN+y1qggwFOKX+bzdPf380x/P939/Tw2ODhUuFHWGqU1ed+nI5Hgz2fMGAKtZPdqILIPZft/SqkhQgxPeLjefA0xcMJiFCNZVFrML5cyBtGECuCA7cM/mg9AAtLK3yAIuKWjg/McBw3c3tlJynHIKzXUPNGxJ+fjbW2saW8nUIofDQzw4cOH2XzyJLccPcod//7vKK1pTyT47zNnDpk9AFJKXi+XWXvkCB986y2WHDrEUwMDKKW4vr2dO2fMqFnYEHbzLNpNvaOra2gdX+jqAq0pa33aoMLwcwkp+a/HjrH68GGuO3yY1W+9xc1Hj1KKgCQtt0Epbu3q4pJkEmHl7mjPrabMyhoDE8NvO24xiqsISnBknf3paioMWpv8ov3lMj8ZHGR2Os2N2SwO8JnOTno8j8cGB0HKEV6rj2UyKLvRXztl1My01Ya/09PDr0sltNasbG2lRYgh1h7dGBd4s1zmj48eZTAIUFrz6fb2ob4EYjSlVUp25vO8Xiyypq2N+a7LFek0V2ez7M3nea5QACGq2shaa65tbWVVayurMxlWZTIsSaVO2/ycUuzJ52mNErEQk1JSLscRS2jIxK3KjX2otxe05o86OvhcZycd6TRb+/t5oVAAq7yFmzo/kUACuSDgsO+bfEN7ijRw0PMQQtApJbNcFz9CANFhTw7wju/zulW23uO6dFgOVItgD3sef9fbi3Bd/rSri1s7O0FKvtXTw/EgACFOf4YQBFrz1TlzeOa972XHhRfyzMKFPDB79mmafFJK7jt1iuOlEjd3djLfdelXauRI60mchjYpvYJrXR1SsiOX4+XBQVZkMtw/ezYEAQ/39tYwM0RDF1bPlZGSH/T1USyV+NKMGXy2s5PeYpGtAwO0S1njlQWv5PM83dfHU/39PN3Xx7P5/GncplUIXimV+JtTp3Bcl/82cyZ+xFJhihtRNLy5sCMEZa15qLeX/9XaSrvj8Fo+z8vFIjdms0NmYLi1RzwPpTUZx2GB63LE80hZywHg4kQCrTW9SnHC93ErTmQoBnzgAmtqKssN+oJgzHfOSMmpIODHAwOs7+wE4Lu9veSUomU0AtAaRwj+4vhxnsjlRvwpEXn3kIDbpeSh3l6+PHMm/7mjg5eLRbD6UHj5dl+EEEghcCJKrLQHJGhw42cp6kxA8GNNRdS4QrClv58Tngeuyzd7eoZ65Vae7B/lckZ5BL583nlgFbMAuK2riwtTKYQQ7MrnKWhNKkIAKvJeC5NJvjd3LlkpkULwf/r7h0SDjuFP/9uQQ2nNw/Z9ldbj6vNzWhqdEAwqxddOnqTVdflQS8tpBPBrz0NY0XhNOk2gNb7WXJ5KkZUSDRy2ZnM1HcKvM0FHAG6cwY0iUggyG3hrFCeLishjF+hXiusOH2am6/JCoWDm99kFqojX67GBAXb093Ndezsfa2vjpwsW8HQ+z6Jkkk+1tyOFoN/z2Hzy5EhvmlJcmkyyff582qTkinSatGuY2lP9/Tz47rtV7eXK9w1P3s/yeVYcOoQH/LJUMiZs5L7KkXWBUtw3axZfmjHDiDCt8YHbjh0bAipKoAL4Vm8vt3d1Mc/6MKL7sLtQ4Ei5zPxUij+bMYM2KelRils6OpDW17HF+gZUFQ/j7EihiIh3oAMXeCUFV5bG6Cil7MNnWQKodrUKgZRyiFqF3UhKpSGTL2nvaZNy6CV9rVl/9CjfVopPtrdzbXs713Z2nuYI2mc9dYHWtEmJlJIZiQRrrHcxCAL2FQo1HUHRK2uf0RI5TT8tFEY0aQrXlInckxQC6ThIrbkikxmpv2hN23FjLKfsZ6W1cEJ7/n+cPMnfz58PSpGNvE+/Unz6nXf4h7lzuTCV4vbZs23VRkAuCLjn+HGeLxRGrcKaZauGB8ZW7lTKVAu9InbC3hRcHYcAWoFb7eSu6EtUuoILSvFCoTD0QCHEkNZ/YSLBRckkyrpACxUgXZFO84F0mlmOQz7iCvbGcAWXteZUna7gD7S00CIlx32f16x7tXIy2BWpFDNcl4Eg4KUYrmANvFQokI+6dq17eECpoe/4T62tQ+t5rlCgZIlEAZ1SsjqT4eJEAkcIfuP7PJvPc8jzqq4p/NzlwHfsWJo4BFCCF8VO2JOCD45FAOFwh/uA/zsJff/EGBVG9dQexg0GMc0HS8T9W4jFJzAt5WIMoQgJ4Dkp4GduTGtLYMar1nr5yhBnrZBwtVGwo4WDVR3h4CAm+LVCrJVrmmg4WNR4/6qDJSJ74NrvH+sAnBffEtC2COhnroZc3PhxOFN3NGpRMUKWY4VSVUzNuxHcJ06Itd6wbV3h3XHu0Wh+koV1KIBWdOUkpvf/mAmhoZkxJ372afPizKWFJSw2fszZD5YAX5QBHPSgMNZo17Ac/ALbqkw308KYLulg2mJyQcxycWlKxAoBHJQDcDiAXltVoscSAR3A+5plYdOuPOx9FpuxREA4YSSA3gE4LP/AdB/bn4hZGewAi5oEMO0IYFHMMLAAZYc87f8DyElh+gH8PI4lEKaFXdksC5t25WFXxk8HCy2An4uwOFTBLhXjUAugiBlm0NUsD5s2ZWFdFpNiPDyEdU/vGgoHJ2FvDvICnLH0AN9+4dLJjCc3r7pi+UstJn4M+S9M99B80hZ4y40gl8OxAPalYugBoda5olkeNm3KwlbEtMqE8QASwL7lcGwjSDnX9geW8HQiph5QsDKnKQamB/u/0mISR/4nDOd4WoCaC47ssifehyf9mBXCHibytLwpBqac/S+3WHgxK4N9izWGeJRcbwlgAH5RhGMJ0y9gTC7gA7/fFANTzv5/P+ZUMW1OvyzCsQHTToD1oKRJY8D5OPQq2JY2ikIwFvXlgN+1P7rJBaakXWy4/7kY+y8gSINWsO3j0GtnDJtWsVuHqWSrNmZCrB7BSeDGplt4yty/N8YsB7emvtSmR9DWKObNZtHNZtHmHzvB+RAUNPwwHRPLADPy/NNNLnDGT/+n7d7HDIurtDnkP/wQFHZGvMZDJ3ynBVzBD/LDw6v1WAkVA5i2k/OJMaayeTUkW2i+3fOBeMWgGjNZvKDgB1GsRxDAZjtP5joTHu7OxOQC4azAO5rWwBnT/u+ob7C0ypjwb/d1cHALOJurEUAFpT0QDA+PJk7V8Arg/U0uMOmn//12r2NWAaNB2FnyD8QqJgnnzD4D3VlYmY8xNVRhmhQexkwMLUQaPjSvxiXMtmAmiC7ABH5iEEDQaqaH7lwNq6rNEJajzQwWsFnXwQXymIjUzU0uMGmn/2a7x/k6Tr9VzjePNkNY1JocbrnAinwd8wMlcBtm0mVzjEzjwP8d4O/q28+gFeQg7Brt9I+qA0S5QJyJ4VFRkDAKJW1N07BhJl+b3dNE/bV/otbpH5UANkCwBZxVsDMHWzMmTyCIQ605THry3U0XccOcPnfbPc3FZ/1BxsT9t9aaHF4zAyhkGTthUQJe88GxLQ1EHAdRF6aK6FGG6+yaF3XV7fvAJzHVPj0xZbA23j3tQuDBkpVwYDT2XzOSK0BpcFbCgSLcl61DpIc9he8GrrILcZqYUk83Nt/u3d2RHsBxJXHWRP3us+A7tZJ8xuIoSoN8A+4dgP1pIwpii6Gy5QKLiWFLNq8RdX6L7d6V63MSqTQ4A7D/DbhXxzi0YyV/6K0gbgNPw+dtJw5VT2PJdsys2yYR1Af+N+ze1dP4UdosXw2fvw28rbZrwUQ7vmDZSPAM/M8uuLMHfBmzvUxgHRgDGBfmvkmoLD4XwW9jOCAT0wLzu8DtgQdXw5dCzBrR8gcNIpwvOBt2t8I1uRidRWoRQVMxPF3hGy/4odafh+eP20y99XZSaEMIgOFcQf00XJQxBaVjDploEsEZAV+75v7eHFy9Bg7ZnmuqoW3i7APlWngzD7cmzRhSvx4WV7AL/Doml90fR4v3c8nJE3Y2W2r3pF7wLYB+EkQebl0Lb1LD5Jtwn0ABQTe4a+DRQdjcCQlt9JTYRFDEDCn6W+NwGmrF8tvkMJKRhhgb7F5k7N7U2ezZ64TEIGxeA492gyvqVK/Gdfi6wV0F/k743x3wR73gCeOprCujtQMz+/ZrkeQGdQ5HEUWks3ob8GVMVm/fOMAIwe+D76+EPw4xmYy+j1WVQoAfQ0sX7GyBpf11WAaVfYfeAL4KvDqOfkBnY++fy4C/BC4mVj+fqhp/O7gF2NsDKz9qJAdiHGdnXGb5ZrumP4XyJ+BRF1ZnYH4RfFEHNw/DyLOA38NkuL5unR/yHBlMJSPJshngM8CfAzOA/nG0ag3BL8LePlj3UdsVbtU4t0pMMD1JClCPQ1enqSkYFycI8wc6LAF8HXguQqFno1iIsnuADwJfBC61LH88ORNR8Hth3Y3Qo+tU+hpKAI0kAsLGjBb0Z4GHMDYNkQxVdZac+BD4i4DPA9fa/8uPp0HzJIHfsCYf1YhgoE7FsHIgctZu1lPAP0YIQUTkqZ5mpz36ThcBfwhcb4l6cAJ1lBq8Nkg0GvyGdnmJEkEHbMvC0t5xEgGRuEGblZXPAD9heGp5pXzVUwR6JVdaavWZ1Rhf/sAEYyARU29vX4PBb3ibn/DFHoO22fBgBj7bA4Gyo5XGSwiu5QglTJvaJ4A9jJxfVK3N62QAXu35s4BlwA2Ydq0pe+InEgZXJq6vukxix3ePw503wUAjwWec4qimt3AjyJsM4X9uFxxpgY0e4NURO6g0U7Q1l8JeOFcDJ4GXgZ8CP8dMzQxGkcdU6ec71mkQFR1MdcXz52Di9R/GFGjOjMj4wihdQOs4SEESnAQ4vbB5BWwC2Nhg8Cet0Zf1EwibUbQhAQ8nYMbgOJXDSh0hbIzYYhfQA+y3BLEfE2c43kCFUWJasS8GLrGAX4LJetIWcK+CS0xgfX4WXA/e9eD2lbAljMOISZB0k+qGD71TT8GiDHyvBZb3myQTxAT3Kip7E5btJizb7QPesUSwH3iX4bGqJzATNqM+hvDf51l2HrbEnWGBng28x5qprgW7xLAPvBHxDG2id7SDLMDuHHzmejgwXg/ftCCAKBFsBPc6uD8Jd2qzgb6NWTfCFB36EZEBl44FTFuwwiqm/CjPabW6RpjdHDbCCKxzKoh8h2jQ5tnGTUHK+PEpw4M74O7N4E82+Ges12NUcdkF61x4IA1LBu3UCtHgRKFoVZKuWKhTg02riJyv/JyYhM3SEEhwskDRJN7etQK2Ve7ZmWg1M9kmkwLEFnBWwLbfwFUF2ORCOTucZxg0WmOXFa3kQ7PNH+VH1/hcg8EPtEnedFwoF2DTb+CqFbBti/laIc6Qz+uMh+KjOerdcFkC7kmaqidyw1ks52rqYKBBZOzBK8MjHty7ysbBauXvnzMEEOlIIsPY9R5Yq+BuB9ba4hJltd5zIV9EWw4nMiAtq9su4f5lsD2Sczklzs2pysPQAoKNpm+NXAbbl8P1nvnZ3gIyaxVEW5F0NkaHlTb6jciC0wLSg+0eXL8crl8G27Vt1CmG9cspazY9pdcWcF4DHTYusBzhCwGsy0KqaKwGJYaDaNM1gUiFtRQpkGljdZQc2Cbhm+GJ3whyCYgN0yA5elqx1y3gRLNZd5vo6c0aPpWES6VNm/KGiSEUJWKKunXokHVrkAkLujLy/XUB/wQ8stxEuYeyqzdMo6z4aSlfLSGEm8sTkOqCdQHcpGFtEuaFDpmyNSVDE10PT0MVkyDLichqIcFJRhxQZXhbwHYHHuuBbTcYfxEa5NZpcuLPCgIIr40gN9nRieH/PQHtWViq4SMSVihYkoGWMMPWG572OURAeuRoRxknIq0jKVbaBrNcC7Zrb8qZUTuvKdgl4MlB2HuDCV4OFdRsiog2pvHAieneGElsBbneZiZH//YCzPfg/Qqu1XClMr0UulKQciLevPAqjfFdKUZGysIgUMl8tEfCrwT8QsKzCXjpA3CksopqK/ELM5oEME5imAViVRXtudvkmc7LwoIcLBPQqszvhDW3LrdzEao1Ywg0vCLMb0/CHg35DOwZNC2Q3l5lApMjPtoNzgnQZwvo0ev/AwF4Cgqwg2nRAAAAAElFTkSuQmCC";
        return env->NewStringUTF(data);
    }

    extern "C" JNIEXPORT jobjectArray JNICALL
    Java_com_android_support_Menu_GetFeatureList(JNIEnv* env, jobject) {
        const char* items[] = {
            "Category_Status",
            "RichTextView_IL2CPP detection checks only this process. It does not inject into a game.",
            "Category_Test",
            "Toggle_Native callback test",
            "Button_Check IL2CPP status",
            "Collapse_Slider",
            "CollapseAdd_SeekBar_Value_1_100",
            "Toggle_Toggles 1",
            "Toggle_Toggles 2",
            "Toggle_Toggles 3",
            "Toggle_Toggles 4",
            "Toggle_Toggles 5","Category_BG","Button_BtnON","Button_BtnOFF","CheckBox_Checkbox 1","CheckBox_Checkbox 2","InputLValue_Input 1","InputLValue_Input 2","InputLValue_Input 3","InputLValue_Input 4","SeekBar_Speed_1_4","RichTextView_Text","RadioButton_Mode_One,Two,Three"
        };
        return makeStrings(env, items, static_cast<jsize>(sizeof(items) / sizeof(items[0])));
    }

    extern "C" JNIEXPORT jobjectArray JNICALL
    Java_com_android_support_Menu_SettingsList(JNIEnv* env, jobject) {
        const char* items[] = {
            "Category_About",
            "RichTextView_Menu.java is preserved unchanged. Test controls verify JNI callbacks only."
        };
        return makeStrings(env, items, static_cast<jsize>(sizeof(items) / sizeof(items[0])));
    }

    extern "C" JNIEXPORT jboolean JNICALL
    Java_com_android_support_Menu_IsGameLibLoaded(JNIEnv*, jobject) {
        return dl_iterate_phdr(findIl2Cpp, nullptr) == 1 ? JNI_TRUE : JNI_FALSE;
    }

    extern "C" JNIEXPORT void JNICALL
    Java_com_android_support_Preferences_Changes(JNIEnv* env, jclass, jobject, jint featNum,
                                                 jstring featName, jint value, jlong longValue,
                                                 jboolean isOn, jstring inputText) {
        const char* name = featName ? env->GetStringUTFChars(featName, nullptr) : nullptr;
        {
            std::lock_guard<std::mutex> lock(gFeatureMutex);
            gFeatureStates[featNum] = (isOn == JNI_TRUE);
        }
        LOGI("Feature callback: id=%d name=%s on=%d value=%d longValue=%lld input=%s",
             static_cast<int>(featNum), name ? name : "(null)", isOn == JNI_TRUE,
             static_cast<int>(value), static_cast<long long>(longValue),
             inputText ? "provided" : "(null)");
        if (name) env->ReleaseStringUTFChars(featName, name);

    }
#define targetLibName OBFUSCATE("libil2cpp.so")

void Changes(JNIEnv *env, jclass clazz, jobject obj, jint featNum, jstring featName, jint value, jlong Lvalue, jboolean boolean, jstring text) {

    switch (featNum) {
        case 0:
            // offset, hex
            PATCH_SWITCH(targetLibName, "0x1079728", "C0 03 5F D6", boolean);
            
            
                        PATCH_SWITCH(targetLibName, "_example__sym", "C0 03 5F D6", boolean);
            // offset, asm
            PATCH_SWITCH(targetLibName, "0x1079728", "ret", boolean);
            // symbol, asm
            PATCH_SWITCH(targetLibName, "_example__sym", "ret", boolean);

            // asm allows you to avoid using hex code, as it is generated automatically from the instructions.
            // - this is the awesome option if you know what you're doing
            // recommended insert ';' to separate statements, example: "mov x0, #1; ret"
            // recommended to test your instructions on https://armconverter.com or
            // https://shell-storm.org/online/Online-Assembler-and-Disassembler/

            // - this is probably especially useful with creating dynamic deep patches
            dPATCH_SWITCH(true, targetLibName, "0x1079728", "mov w%d, #%d", 0, 222);
            dPATCH_SWITCH(true, targetLibName, "_example__sym", "mov w%d, #%d", 0, 222);
            // standard formatting specifiers are supported (%d, %i, %x, %s, etc.)
            