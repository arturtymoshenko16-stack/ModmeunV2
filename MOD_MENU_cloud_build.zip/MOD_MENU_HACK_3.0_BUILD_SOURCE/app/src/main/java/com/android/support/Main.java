package com.android.support;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.widget.Toast;

/** Android-side bootstrap for the native menu library. */
public final class Main {
    static {
        System.loadLibrary("GkModMenu");
    }

    private Main() { }

    public static void Start(Context context) {
        if (context == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && !Settings.canDrawOverlays(context)) {
            if (context instanceof Activity) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + context.getPackageName()));
                ((Activity) context).startActivityForResult(intent, 7401);
                Toast.makeText(context, "Разреши отображение поверх других приложений, затем вернись в меню.", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(context, "Сначала разреши отображение поверх других приложений.", Toast.LENGTH_LONG).show();
            }
            return;
        }
        try {
            context.startService(new Intent(context, Launcher.class));
        } catch (RuntimeException error) {
            Toast.makeText(context, "Не удалось запустить меню: " + error.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public static void StartWithoutPermission(Context context) {
        if (context instanceof Activity) {
            Menu menu = new Menu(context);
            menu.SetWindowManagerActivity();
            menu.ShowMenu();
        } else {
            Toast.makeText(context, "Для запуска меню требуется Activity.", Toast.LENGTH_LONG).show();
        }
    }
}
