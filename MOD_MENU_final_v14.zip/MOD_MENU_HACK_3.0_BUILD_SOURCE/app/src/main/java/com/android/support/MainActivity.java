package com.android.support;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.view.Gravity;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(24, 24, 24, 24);
        TextView info = new TextView(this);
        info.setText("MOD MENU");
        info.setGravity(Gravity.CENTER);
        layout.addView(info);
        setContentView(layout);Main.Start(this);Main.Start(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // If the user returned from the overlay permission screen, start the menu.
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.M
                || android.provider.Settings.canDrawOverlays(this)) {
            Main.Start(MainActivity.this);
        }
    }
}
