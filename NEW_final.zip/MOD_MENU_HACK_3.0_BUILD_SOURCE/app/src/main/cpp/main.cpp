\
    #include <jni.h>
    #include <android/log.h>
    #include <link.h>
    #include <cstring>
#include <mutex>
#include <unordered_map>

    #define LOG_TAG "GkModMenu"
    #define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
static std::mutex gFeatureMutex;
static std::unordered_map<int, bool> gFeatureStates;

    namespace {
    const char* kIconBase64 =
        "iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAABJklEQVR42u3bwQ0AEAxAUTtbwFriYBFWsAJL6EE8yV+geaemUspt6+MMAQBDAEAACAABIAAEgAAQAAJAAAgAASAABIAAEAACQAAIAAEgAASAABAAAkAACAABIAAEgAAQAPoNQB9LAT0DwIt5AAAAAAAAAAAAAAAAAAAAAABgEWQRZBUsAASAABAAAkAACAABIAAEgAAQAAJA7gHcAwAAAAAAAAAAAAAAAAAAAAAAAAAA3KzUqYCsggWAABAAAkAACAABIAAEgAAQAAJAAMg9gHsAAAAAAAAAAAAAAAAAAAAAAAAAAAD/AvwLsAoWAAJAAAgAAAwBAAEgAASAABAAAkAACAABIAAEgAAQAAJAAAgAASAABIAAEAACQAAIAAEgAASAANATHcuami3I1TPjAAAAAElFTkSuQmCC";

    int findIl2Cpp(struct dl_phdr_info* info, size_t, void*) {
        return (info && info->dlpi_name && std::strstr(info->dlpi_name, "libil2cpp.so")) ? 1 : 0;
    }

    jobjectArray makeStrings(JNIEnv* env, const char* const* values, jsize count) {
        jclass stringClass = env->FindClass("java/lang/String");
        if (stringClass == nullptr) return nullptr;
        jobjectArray array = env->NewObjectArray(count, stringClass, nullptr);
        if (array == nullptr) {
            env->DeleteLocalRef(stringClass);
            return nullptr;
        }
        for (jsize i = 0; i < count; ++i) {
            jstring value = env->NewStringUTF(values[i]);
            if (value == nullptr) break;
            env->SetObjectArrayElement(array, i, value);
            env->DeleteLocalRef(value);
        }
        env->DeleteLocalRef(stringClass);
        return array;
    }
    }

    extern "C" JNIEXPORT void JNICALL
    Java_com_android_support_Menu_Init(JNIEnv* env, jobject, jobject, jobject title, jobject subtitle) {
        jclass textView = env->FindClass("android/widget/TextView");
        if (textView == nullptr) return;
        jmethodID setText = env->GetMethodID(textView, "setText", "(Ljava/lang/CharSequence;)V");
        if (setText != nullptr) {
            jstring titleText = env->NewStringUTF("MOD MENU");
            const bool loaded = dl_iterate_phdr(findIl2Cpp, nullptr) == 1;
            jstring subtitleText = env->NewStringUTF(loaded ? "Native bridge loaded | IL2CPP detected" : "Native bridge loaded | IL2CPP not in this process");
            if (title && titleText) env->CallVoidMethod(title, setText, titleText);
            if (subtitle && subtitleText) env->CallVoidMethod(subtitle, setText, subtitleText);
            if (titleText) env->DeleteLocalRef(titleText);
            if (subtitleText) env->DeleteLocalRef(subtitleText);
        }
        env->DeleteLocalRef(textView);
        LOGI("Native menu bridge initialized");
    }

    extern "C" JNIEXPORT jstring JNICALL
    Java_com_android_support_Menu_Icon(JNIEnv* env, jobject) {
        return env->NewStringUTF(kIconBase64);
    }

    extern "C" JNIEXPORT jstring JNICALL
    Java_com_android_support_Menu_IconWebViewData(JNIEnv* env, jobject) {
        static const char data[] = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAABJklEQVR42u3bwQ0AEAxAUTtbwFriYBFWsAJL6EE8yV+geaemUspt6+MMAQBDAEAACAABIAAEgAAQAAJAAAgAASAABIAAEAACQAAIAAEgAASAABAAAkAACAABIAAEgAAQAPoNQB9LAT0DwIt5AAAAAAAAAAAAAAAAAAAAAABgEWQRZBUsAASAABAAAkAACAABIAAEgAAQAAJA7gHcAwAAAAAAAAAAAAAAAAAAAAAAAAAA3KzUqYCsggWAABAAAkAACAABIAAEgAAQAAJAAMg9gHsAAAAAAAAAAAAAAAAAAAAAAAAAAAD/AvwLsAoWAAJAAAgAAAwBAAEgAASAABAAAkAACAABIAAEgAAQAAJAAAgAASAABIAAEAACQAAIAAEgAASAANATHcuami3I1TPjAAAAAElFTkSuQmCC";
        return env->NewStringUTF(data);
    }

    extern "C" JNIEXPORT jobjectArray JNICALL
    Java_com_android_support_Menu_GetFeatureList(JNIEnv* env, jobject) {
        const char* items[] = {
            "Category_Status",
            "RichTextView_IL2CPP detection checks only this process. It does not inject into a game.",
            "Category_Test",
            "Toggle_Native callback test",
            "Button_Check IL2CPP status",
            "Collapse_Slider",
            "CollapseAdd_SeekBar_Value_1_100",
            "Button_Кнопка 1",
            "Button_Кнопка 2",
            "Button_Кнопка 3",
            "Button_Кнопка 4",
            "Button_Кнопка 5"
        };
        return makeStrings(env, items, static_cast<jsize>(sizeof(items) / sizeof(items[0])));
    }

    extern "C" JNIEXPORT jobjectArray JNICALL
    Java_com_android_support_Menu_SettingsList(JNIEnv* env, jobject) {
        const char* items[] = {
            "Category_About",
            "RichTextView_Menu.java is preserved unchanged. Test controls verify JNI callbacks only."
        };
        return makeStrings(env, items, static_cast<jsize>(sizeof(items) / sizeof(items[0])));
    }

    extern "C" JNIEXPORT jboolean JNICALL
    Java_com_android_support_Menu_IsGameLibLoaded(JNIEnv*, jobject) {
        return dl_iterate_phdr(findIl2Cpp, nullptr) == 1 ? JNI_TRUE : JNI_FALSE;
    }

    extern "C" JNIEXPORT void JNICALL
    Java_com_android_support_Preferences_Changes(JNIEnv* env, jclass, jobject, jint featNum,
                                                 jstring featName, jint value, jlong longValue,
                                                 jboolean isOn, jstring inputText) {
        const char* name = featName ? env->GetStringUTFChars(featName, nullptr) : nullptr;
        {
            std::lock_guard<std::mutex> lock(gFeatureMutex);
            gFeatureStates[featNum] = (isOn == JNI_TRUE);
        }
        LOGI("Feature callback: id=%d name=%s on=%d value=%d longValue=%lld input=%s",
             static_cast<int>(featNum), name ? name : "(null)", isOn == JNI_TRUE,
             static_cast<int>(value), static_cast<long long>(longValue),
             inputText ? "provided" : "(null)");
        if (name) env->ReleaseStringUTFChars(featName, name);
        // This is a working Java-to-native callback/test dispatcher. Actual game
        // modifications must be implemented for a specific authorized game; the
        // original archive contains no game-specific IL2CPP methods or handlers.
    }
